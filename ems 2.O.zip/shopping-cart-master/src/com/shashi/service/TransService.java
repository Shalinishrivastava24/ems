package com.shashi.service;

public interface TransService {

	public String getUserId(String transId);
}
